# line

> Read a single line of input.

- Read input:

`line`
