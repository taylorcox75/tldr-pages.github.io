# sensors

> Report sensors information.

- Show the current readings of all sensor chips:

`sensors`

- Show temperatures in degrees Fahrenheit:

`sensors --fahrenheit`
