# silentcast

> Silent screencast creator. Saves in `.mkv` and animated gif formats.
> More information: <https://github.com/colinkeenan/silentcast>.

- Launch silentcast:

`silentcast`

- Launch silentcast on a specific display:

`silentcast --display={{display}}`
