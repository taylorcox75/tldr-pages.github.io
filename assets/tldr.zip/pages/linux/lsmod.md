# lsmod

> Shows the status of linux kernel modules.
> See also `modprobe`, which loads kernel modules.

- List all currently loaded kernel modules:

`lsmod`
