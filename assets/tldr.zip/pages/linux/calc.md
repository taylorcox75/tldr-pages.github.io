# calc

> An interactive arbitrary-precision calculator on the terminal.

- Start calc in interactive mode:

`calc`

- Perform a calculation in non-interactive mode:

`calc -p '{{85 * (36 / 4)}}'`
