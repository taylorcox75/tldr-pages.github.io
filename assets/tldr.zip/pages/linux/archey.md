# archey

> Simple tool for stylishly displaying system information.

- Show system information:

`archey`
