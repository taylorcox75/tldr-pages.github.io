# fc-pattern

> Shows information about a font matching a pattern.

- Display default information about a font:

`fc-pattern -d '{{DejaVu Serif}}'`
